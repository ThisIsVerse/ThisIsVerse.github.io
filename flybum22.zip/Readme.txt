  FlyBum 2.2
  Java Special F/X creator for Windows 95/98/NT


  [THE PURPOSE]

  FlyBum is a small application you can use to add custom animations to your Website.
  It allows you to add one or more graphics, which it moves within the borders of the
  Java applet it creates.
  Define start and final positions, delay before moving, and add an optional HTML link
  for each graphic.
  You can also establish the number of steps, step delay, default HTML link, background
  color, sounds, and default mouse behavior for the applet.
  You can preview the results in your default Web browser, build the applet, or copy
  the required HTML code to the Clipboard for pasting into your Web page.
  A hex color conversion utility is also included.


  [INSTALLATION]

  The program is for Windows 95, Windows NT and Window 98
  Run SETUP.EXE
  and follow onscreen instructions.
  In some cases you may need to empty Windows\Temp directory before installation.


  [MAKING THE APPLET]

  FlyBum will copy all the files necessary for running the applet into "Output" folder,
  including an HTML file, the FlyBum2v2.class file, the archive file FlyBum2v2.cab,
  and all the picture files required by the applet. 
  After the applet has been built upload ALL the files in this folder to your web server.
� Nothing further is necessary for the applet to run. 


  [HOW TO PURCHASE]

  FlyBum is SHAREWARE. You are allowed 30 days to evaluate it and decide
  if it's of any use to you. The registration fee is: $20.00 (U.S. Dollars)
  To get your Registration Number go to the Secure Registration Form:
  https://www.regnow.com/softsell/nph-softsell.cgi?item=2189-2


  [COPYRIGHT INFORMATION]

  This software is provided as-is, without warranty of ANY KIND, either expressed or implied,
  including but not limited to the implied warranties of merchant ability and/or fitness for 
  a particular purpose. The author shall NOT be held liable for ANY damage to you, your
  computer, or to anyone or anything else, that may result from its use, or misuse.

  All trademarks and other registered names contained in the FlyBum package are the property
  of their respective owners.  

  
  [BUG REPORTS]

  If you find any bugs please email them to:
  flybum@mailcity.com


  Use of this software indicates that you agree to the above conditions.


  [DISTRIBUTION]

  Program is FREE to distribute on any kind of media.
  However, if you contact me (flybum@mailcity.com) before putting FlyBum
  on a CD or your website I can assure you that you are including the
  latest version of FlyBum. You will also have to mention that the people
  who buy the CD, pay for the CD and not for FlyBum.

  Though I cannot oblige you to do so, if you put FlyBum on a CD-ROM, I 
  would really like to receive a free copy of that CD.


  [CONTACT]

  Yuri Margolin
  homepage: http://flybum.hypermart.net
  e-mail: flybum@mailcity.com

  Enjoy!
  
  5-Sep-1999
  Israel, Jerusalem.
  